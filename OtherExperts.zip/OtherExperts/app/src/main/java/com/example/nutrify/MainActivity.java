package com.example.nutrify;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.example.nutrify.expert.Expert;
import com.example.nutrify.expert.MacroMatcher;
import com.example.nutrify.expert.LLMRecommender;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Test Macro Matcher
        Expert matcher = new MacroMatcher();
        String result1 = matcher.getExpertAnswer("300,25,10,20");
        Log.d("MACRO_RESULT", "Macro Matcher: " + result1);

        // Test LLM Recommender
        Expert llm = new LLMRecommender();
        String result2 = llm.getExpertAnswer("High protein, low fat meal under 400 calories");
        Log.d("LLM_RESULT", "LLM Recommender: " + result2);
    }
}
