package com.example.nutrify.expert;

public interface Expert {
    String getExpertAnswer(String input);
}
